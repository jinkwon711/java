/** Source code example for "A Practical Introduction to Data
    Structures and Algorithm Analysis, 3rd Edition (Java)" 
    by Clifford A. Shaffer
    Copyright 2008-2011 by Clifford A. Shaffer
 */

/** Linked list implementation */
class SingleLinkedList<E> implements List<E> {
	private Link<E> head;         // Pointer to list header
	private Link<E> tail;         // Pointer to last element
	protected Link<E> curr;       // Access to current element
	int cnt;		      // Size of list

	/** Constructors */
	SingleLinkedList(int size) { this(); }   // Constructor -- Ignore size
	SingleLinkedList() {
		curr=tail=head=new Link<E>(null);
		cnt=0;

	}

	/** Remove all elements */
	public void clear() {
		head.setNext(null);         // Drop access to links
		curr = tail = head = new Link<E>(null); // Create header
		cnt = 0;
	}

	/** Insert "it" at (pos) position */
	public void insert(int pos, E it) {
		moveToPos(pos-1);
		curr.setNext(new Link<E>(it, curr.next()));
		if(tail==curr) tail = curr.next();
		cnt++;
	}

	/** Remove and return an element at (pos) position*/
	public E remove(int pos) {
		moveToPos(pos-1);
		if(curr.next() == null) return null;
		E it = curr.next().element();
		if(tail==curr.next()) tail = curr;
		curr.setNext(curr.next().next());
		cnt--;
				
		return it;
		 // Return value
	}

	/** Set curr at list start */
	public void moveToStart(){
		curr = head; 
	}
	/** Set curr at list end */
	public void moveToEnd(){ 
		curr = tail; 
	}

	/** Move curr one step left; no change if now at front */
	public void prev() {
		if (curr == head) return; // No previous element
		Link<E> temp = head;
		// March down list until we find the previous element
		while (temp.next() != curr) temp = temp.next();
		curr = temp;
	}

	/** Move curr one step right; no change if now at end */
	public void next(){ 
		if (curr != tail) curr = curr.next();
	}

	/** @return List length */
	public int length() {
		moveToEnd();
		return currPos(); // Return value
	}

	/** @return The position of the current element */
	public int currPos() {
		Link<E> temp = head;
		int i;
		for (i=0; curr != temp; i++)
		temp = temp.next();
		return i;
	}

	/** Move down list to "pos" position */
	public void moveToPos(int pos) {
		assert (pos>=0) && (pos<=cnt) : "Position out of range";
		curr = head;
		for(int i=0; i<pos; i++) curr = curr.next();
	}

	/** @return an element value at (pos) position*/
	public E getValue(int pos) {
		moveToPos(pos);
		E it = curr.element();
		return it; // Return value
	}



}